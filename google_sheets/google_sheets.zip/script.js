// script.js

// Function to send a message to the background script
function sendMessageToBackground(action, callback) {
    chrome.runtime.sendMessage({ action: action }, callback);
  }
  
  window.onload = function () {
    const extractedData = { "Wind": '20', "Humidity": '82', "Visibility": '24', "Sunrise": '6:38' };
  
    sendMessageToBackground("authenticate", function (response) {
      if (response.error) {
        console.error(response.error);
        return;
      }
  
      const token = response.token;
  
      fetch('https://script.google.com/macros/s/AKfycby0m6yC128Ggnq16gfYOIVItDWG4zYCG2mfiOBjhV2JXC4FL7a34c5MjTXf401WujrA/exec', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(extractedData),
        mode: 'cors',
      })
        .then(response => response.text())
        .then(result => {
          console.log(result);
        })
        .catch(error => {
          console.error('Error:', error);
        });
    });
  };
  